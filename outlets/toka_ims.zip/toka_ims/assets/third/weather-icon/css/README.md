# Weather Icons
*Version Beta 1 - August 3rd 2013*

If you want to just include the CSS itself, just reference this file. Make sure you have the `font` folder that holds all the font files a level above the CSS folder. If you want to change it, you'll have to edit it in the source.